import 'package:flutter/material.dart';
import 'package:flutter_application_1/home_screen.dart';
import 'package:flutter_application_1/trial3/main3.dart';
import 'package:flutter_application_1/trial3/home_screen_copy.dart';

class Nav extends StatefulWidget {
  @override
  _NavState createState() => _NavState();
}

class _NavState extends State<Nav> {
  int _selectedIndex = 0;
  List<Widget> _widgetOptions = <Widget>[
    Home(),
    Page2(),
    HomeScreen(),
  ];

  void _onItemTap(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
      length: 4,
      child: Scaffold(
          appBar: AppBar(
            title: Text('Bottom Navigation Bar Tutorial'),
            leading: IconButton(icon: Icon(Icons.menu), onPressed: () {}),
            actions: [
              IconButton(
                icon: Icon(Icons.notifications_none),
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(Icons.search),
                onPressed: () {},
              ),
            ],
            flexibleSpace: Container(
              decoration: BoxDecoration(
                  gradient: LinearGradient(
                colors: [Colors.red, Colors.purple],
                begin: Alignment.bottomRight,
                end: Alignment.topLeft,
              )),
            ),
            bottom: TabBar(indicatorColor: Colors.yellow, indicatorWeight: 5,
                //isScrollable: true,
                tabs: [
                  Tab(icon: Icon(Icons.home), text: 'Home'),
                  Tab(icon: Icon(Icons.star), text: 'Feed'),
                  Tab(icon: Icon(Icons.face), text: 'Profile'),
                  Tab(icon: Icon(Icons.settings), text: 'Settings'),
                ]),
            backgroundColor: Colors.orange,
            elevation: 20,
            titleSpacing: 20,
          ),
          body: TabBarView(children: [
            Home(),
            Page2(),
            HomeScreen(),
            buildPage('Setting Page'),
          ])));

  Widget buildPage(String text) => Center(
        child: Text(
          text,
          style: TextStyle(fontSize: 28),
        ),
      );
}
