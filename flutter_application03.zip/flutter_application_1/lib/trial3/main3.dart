import 'package:flutter/material.dart';
import 'package:flutter_application_1/home_screen.dart';
import 'package:flutter_application_1/trial3/iintroduction_screen.dart';
import 'package:flutter_application_1/trial3/home_screen_copy.dart';
import 'package:shared_preferences/shared_preferences.dart';

bool show = true;
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  show = prefs.getBool('ON_BOARDING') ?? true;
  runApp(MyApp3());
}

class MyApp3 extends StatelessWidget {
  const MyApp3({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      // title: 'Material Apps',
      // theme: ThemeData(
      //   primarySwatch: Colors.red,
      // ),
      home: show ? IntroScreen() : const HomeScreen(),
    );
  }
}
